function startHeartRateMonitor() {
    if ("serial" in navigator) {
        navigator.serial.requestPort().then(port => {
            port.open({ baudRate: 9600 }).then(() => {
                const reader = port.readable.getReader();
                reader.read().then(({ value, done }) => {
                    if (!done) {
                        let bpm = new TextDecoder().decode(value).trim();
                        document.getElementById("bpm-value").innerText = bpm;
                    }
                });
            });
        }).catch(err => {
            alert("Serial connection failed: " + err.message);
        });
    } else {
        alert("Web Serial API not supported in your browser.");
    }
}
