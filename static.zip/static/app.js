/* app.js */
// Base API URL (adjust if needed)
const API_BASE = "http://localhost:8002/api";

// Patient registration
if(document.getElementById("patientRegisterForm")){
    document.getElementById("patientRegisterForm").addEventListener("submit", async function(e){
        e.preventDefault();
        const name = document.getElementById("patientName").value;
        const email = document.getElementById("patientEmail").value;
        const password = document.getElementById("patientPassword").value;
        const dob = document.getElementById("patientDOB").value;
        try {
            const res = await fetch(API_BASE + "/register/patient", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({name, email, password, dob})
            });
            const data = await res.json();
            document.getElementById("patientRegisterMsg").innerText = data.message || data.detail;
        } catch(error) {
            document.getElementById("patientRegisterMsg").innerText = "Registration failed.";
        }
    });
}

// Doctor registration
if(document.getElementById("doctorRegisterForm")){
    document.getElementById("doctorRegisterForm").addEventListener("submit", async function(e){
        e.preventDefault();
        const name = document.getElementById("doctorName").value;
        const email = document.getElementById("doctorEmail").value;
        const password = document.getElementById("doctorPassword").value;
        const specialization = document.getElementById("doctorSpecialization").value;
        try {
            const res = await fetch(API_BASE + "/register/doctor", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({name, email, password, specialization})
            });
            const data = await res.json();
            document.getElementById("doctorRegisterMsg").innerText = data.message || data.detail;
        } catch(error) {
            document.getElementById("doctorRegisterMsg").innerText = "Registration failed.";
        }
    });
}

// Login
if(document.getElementById("loginForm")){
    document.getElementById("loginForm").addEventListener("submit", async function(e){
        e.preventDefault();
        const email = document.getElementById("loginEmail").value;
        const password = document.getElementById("loginPassword").value;
        const role = document.getElementById("roleSelect").value;
        try {
            const res = await fetch(API_BASE + "/login", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({email, password, role})
            });
            const data = await res.json();
            if(data.user){
                if(role === "patient"){
                    localStorage.setItem("patient", JSON.stringify(data.user));
                    window.location.href = "dashboard_patient.html";
                } else {
                    localStorage.setItem("doctor", JSON.stringify(data.user));
                    window.location.href = "dashboard_doctor.html";
                }
            } else {
                document.getElementById("loginMsg").innerText = data.detail;
            }
        } catch(error) {
            document.getElementById("loginMsg").innerText = "Login failed.";
        }
    });
}

// Patient Dashboard
if(document.getElementById("patientSymptomForm")){
    const patient = JSON.parse(localStorage.getItem("patient"));
    document.getElementById("patientNameDisplay").innerText = patient.name;
    
    document.getElementById("getDiagnosisBtn").addEventListener("click", async function(){
        const symptoms = document.getElementById("symptomText").value;
        const formData = new FormData();
        formData.append("symptoms", symptoms);
        try {
            const res = await fetch(API_BASE + "/diagnosis", {
                method: "POST",
                body: formData
            });
            const data = await res.json();
            document.getElementById("diagnosisText").value = data.diagnosis;
        } catch(error) {
            document.getElementById("diagnosisText").value = "Diagnosis unavailable.";
        }
    });

    // Audio recording using MediaRecorder API
    let mediaRecorder;
    let audioChunks = [];
    const recordBtn = document.getElementById("recordAudioBtn");
    const audioPlayerContainer = document.getElementById("audioPlayerContainer");

    recordBtn.addEventListener("click", async function(){
        if(recordBtn.innerText === "Record Audio"){
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            mediaRecorder.start();
            recordBtn.innerText = "Stop Recording";
            mediaRecorder.addEventListener("dataavailable", event => {
                audioChunks.push(event.data);
            });
            mediaRecorder.addEventListener("stop", () => {
                const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
                const audioUrl = URL.createObjectURL(audioBlob);
                audioPlayerContainer.innerHTML = `<audio controls src="${audioUrl}"></audio>`;
                const formData = new FormData();
                formData.append("file", audioBlob, "recording.wav");
                fetch(API_BASE + "/transcribe", {
                    method: "POST",
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    document.getElementById("symptomText").value = data.transcription;
                })
                .catch(err => console.error("Transcription error", err));
            });
        } else {
            mediaRecorder.stop();
            recordBtn.innerText = "Record Audio";
            audioChunks = [];
        }
    });

    // Submit symptom & diagnosis form (including specialty)
    document.getElementById("patientSymptomForm").addEventListener("submit", async function(e){
        e.preventDefault();
        const symptoms = document.getElementById("symptomText").value;
        const diagnosis = document.getElementById("diagnosisText").value;
        const specialty = document.getElementById("specialtySelect").value;
        const patientId = patient.id;
        const formData = new FormData();
        formData.append("symptoms", symptoms);
        formData.append("diagnosis", diagnosis);
        formData.append("patient_id", patientId);
        formData.append("specialty", specialty);
        try {
            const res = await fetch(API_BASE + "/patient/submit", {
                method: "POST",
                body: formData
            });
            const data = await res.json();
            document.getElementById("patientMsg").innerText = data.message;
            loadPatientHistory(); // Refresh history after submission
        } catch(error) {
            document.getElementById("patientMsg").innerText = "Submission failed.";
        }
    });
    
    // Function to load patient history
    async function loadPatientHistory(){
        try {
            const res = await fetch(API_BASE + `/patient/history/${patient.id}`);
            const data = await res.json();
            const historyContainer = document.getElementById("patientHistory");
            if(historyContainer){
                if(data.history.length > 0){
                    historyContainer.innerHTML = data.history.map(record => `
                        <div class="card mb-2 shadow-sm">
                          <div class="card-body">
                            <p><strong>Time:</strong> ${record.timestamp}</p>
                            <p><strong>Symptoms:</strong> ${record.symptoms}</p>
                            <p><strong>Diagnosis:</strong> ${record.diagnosis}</p>
                            ${record.feedback ? `<p><strong>Feedback:</strong> ${record.feedback} <br><em>by Dr. ${record.doctor_name} (${record.doctor_specialty})</em></p>` : ''}
                          </div>
                        </div>
                    `).join("");
                } else {
                    historyContainer.innerHTML = `<p>No history available.</p>`;
                }
            }
        } catch(error){
            console.error("Error loading patient history", error);
        }
    }
    
    // Load history on page load
    loadPatientHistory();
}

// Doctor Dashboard
if(document.getElementById("recordsList")){
    const doctor = JSON.parse(localStorage.getItem("doctor"));
    document.getElementById("doctorNameDisplay").innerText = doctor.name;
    
    // Load available records (for pending feedback)
    function loadRecords(){
        fetch(API_BASE + `/doctor/records/${doctor.id}`)
        .then(res => res.json())
        .then(data => {
            const recordsList = document.getElementById("recordsList");
            recordsList.innerHTML = "";
            data.records.forEach(record => {
                const recordDiv = document.createElement("div");
                recordDiv.classList.add("col-md-6");
                recordDiv.innerHTML = `
                    <div class="card shadow-sm">
                      <div class="card-body">
                        <p><strong>Patient:</strong> ${record.patient_name}</p>
                        <p><strong>Symptoms:</strong> ${record.symptoms}</p>
                        <p><strong>Diagnosis:</strong> ${record.diagnosis}</p>
                        <p><strong>Time:</strong> ${record.timestamp}</p>
                        <textarea placeholder="Enter feedback" class="form-control feedback-input mb-2" data-record-id="${record.id}"></textarea>
                        <button class="btn btn-sm btn-success submit-feedback" data-record-id="${record.id}">Submit Feedback</button>
                      </div>
                    </div>
                `;
                recordsList.appendChild(recordDiv);
            });
            
            document.querySelectorAll(".submit-feedback").forEach(button => {
                button.addEventListener("click", async function(){
                    const recordId = this.getAttribute("data-record-id");
                    const feedbackInput = document.querySelector(`.feedback-input[data-record-id="${recordId}"]`);
                    const feedback = feedbackInput.value;
                    try {
                        const res = await fetch(API_BASE + "/doctor/feedback", {
                            method: "POST",
                            headers: {"Content-Type": "application/json"},
                            body: JSON.stringify({record_id: recordId, feedback, doctor_id: doctor.id})
                        });
                        const data = await res.json();
                        alert(data.message);
                        loadDoctorHistory(); // Refresh doctor history after feedback
                        loadRecords(); // Refresh pending records as well
                    } catch(error) {
                        alert("Feedback submission failed.");
                    }
                });
            });
        });
    }
    
    loadRecords();
    
    // Function to load doctor's history (records with feedback)
    async function loadDoctorHistory(){
        try {
            const res = await fetch(API_BASE + `/doctor/history/${doctor.id}`);
            const data = await res.json();
            const historyContainer = document.getElementById("doctorHistory");
            if(historyContainer){
                if(data.history.length > 0){
                    historyContainer.innerHTML = data.history.map(record => `
                        <div class="card mb-2 shadow-sm">
                          <div class="card-body">
                            <p><strong>Patient:</strong> ${record.patient_name} (${record.patient_email})</p>
                            <p><strong>Time:</strong> ${record.feedback_timestamp}</p>
                            <p><strong>Symptoms:</strong> ${record.symptoms}</p>
                            <p><strong>Diagnosis:</strong> ${record.diagnosis}</p>
                            <p><strong>Feedback:</strong> ${record.feedback}</p>
                          </div>
                        </div>
                    `).join("");
                } else {
                    historyContainer.innerHTML = `<p>No history available.</p>`;
                }
            }
        } catch(error){
            console.error("Error loading doctor history", error);
        }
    }
    
    // Load doctor's history on page load
    loadDoctorHistory();
}
