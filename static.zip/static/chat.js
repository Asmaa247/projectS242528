document.getElementById('sendBtn').addEventListener('click', sendMessage);
document.getElementById('userInput').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
});

function sendMessage() {
    let userInput = document.getElementById('userInput');

    if (userInput.value.trim() !== "") {
        let temp = `<p class="userText"><span>${userInput.value}</span></p>`;
        document.getElementById('chatbox').innerHTML += temp;

        fetch('https://doctorchatbot.devssh.xyz/doctor-chat/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ session_id: "unique-session-id", query: userInput.value })
        })
        .then(response => response.json())
        .then(data => {
            let temp = `<p class="botText"><span>${data.message}</span></p>`;
            document.getElementById('chatbox').innerHTML += temp;
            updateScroll();
        })
        .catch(error => console.error('Error:', error));

        userInput.value = "";
    }
}

// Scroll to the latest message
function updateScroll() {
    var element = document.getElementById("chatbox");
    element.scrollTop = element.scrollHeight;
}
